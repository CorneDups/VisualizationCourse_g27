import * as universal from "../../../../src/routes/flowers/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/flowers/+page.svelte";