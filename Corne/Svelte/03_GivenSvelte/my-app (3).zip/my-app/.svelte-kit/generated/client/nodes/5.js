import * as universal from "../../../../src/routes/flowers/[slug]/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/flowers/[slug]/+page.svelte";