import * as universal from "../../../../src/routes/flights/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/flights/+page.svelte";