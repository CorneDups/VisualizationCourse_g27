<h1>Example svelte project</h1>

Check out the:
<ul>
    <li><a href="flowers/">flowers</a></li>
    <li><a href="flights/">flights</a></li>
</ul>