<script>
  export let data;
</script>

<p>Back <a href="/">home</a></p>

{JSON.stringify(data.flower)}