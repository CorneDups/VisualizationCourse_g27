<script>
    import PieChart from '../components/PieChart.svelte';
    import Modal from '../components/modal.svelte';
    import BoxModal18 from '../components/boxmodal18.svelte';
    import Boxmodal19 from '../components/boxmodal19.svelte';
    import Boxmodal20 from '../components/boxmodal20.svelte';
    import Boxmodal21 from '../components/boxmodal21.svelte';
    import Boxmodal22 from '../components/boxmodal22.svelte';
    import Boxmodal23 from '../components/boxmodal23.svelte';
    import Boxmodal24 from '../components/boxmodal24.svelte';
    import Boxmodal25 from '../components/boxmodal25.svelte';
    import Boxmodal26 from '../components/boxmodal26.svelte';
    import Boxmodal27 from '../components/boxmodal27.svelte';
    import Boxmodal28 from '../components/boxmodal28.svelte';
    import Boxmodal29 from '../components/boxmodal29.svelte';
    import Boxmodal30 from '../components/boxmodal30.svelte';
    import Boxmodal31 from '../components/boxmodal31.svelte';
    import Boxmodal32 from '../components/boxmodal32.svelte';
    import Boxmodal33 from '../components/boxmodal33.svelte';
    import Boxmodal34 from '../components/boxmodal34.svelte';
    import Boxmodal35 from '../components/boxmodal35.svelte';
    import Boxmodal36 from '../components/boxmodal36.svelte';
    import Boxmodal37 from '../components/boxmodal37.svelte';
    import Boxmodal38 from '../components/boxmodal38.svelte';
    import './global.css'; // Import the global CSS file here

    // Manually specify the percentages
    const manualPercentages = {
    '18': { percentage: 0.38970588, 'Antwerp': 49.446975, 'Wrocław': 24.007807, 'Lyon': 26.024723, 'Birmingham': 0.520494, 'Göthenburg': 0.000000 },
    '19': { percentage: 0.44447262, 'Antwerp': 40.330861, 'Wrocław': 17.455790, 'Lyon': 22.932116, 'Birmingham': 0.627496, 'Göthenburg': 18.653736 },
    '20': { percentage: 0.70867140, 'Antwerp': 44.400716, 'Wrocław': 19.785331, 'Lyon': 23.327370, 'Birmingham': 0.608229, 'Göthenburg': 11.878354 },
    '21': { percentage: 0.73123732, 'Antwerp': 41.643551, 'Wrocław': 16.990291, 'Lyon': 22.746186, 'Birmingham': 0.832178, 'Göthenburg': 17.787795 },
    '22': { percentage: 0.76166329, 'Antwerp': 40.412783, 'Wrocław': 18.675100, 'Lyon': 22.037284, 'Birmingham': 0.466045, 'Göthenburg': 18.408788 },
    '23': { percentage: 1.00000000, 'Antwerp': 43.914807, 'Wrocław': 19.219067, 'Lyon': 22.996957, 'Birmingham': 0.481744, 'Göthenburg': 13.387424 },
    '24': { percentage: 0.22312373, 'Antwerp': 11.477273, 'Wrocław': 3.750000, 'Lyon': 6.590909, 'Birmingham': 0.113636, 'Göthenburg': 78.068182 },
    '25': { percentage: 0.06465517, 'Antwerp': 41.176471, 'Wrocław': 20.784314, 'Lyon': 21.568627, 'Birmingham': 1.176471, 'Göthenburg': 15.294118 },
    '26': { percentage: 0.06795132, 'Antwerp': 42.164179, 'Wrocław': 17.537313, 'Lyon': 20.149254, 'Birmingham': 0.000000, 'Göthenburg': 20.149254 },
    '27': { percentage: 0.05451318, 'Antwerp': 40.465116, 'Wrocław': 20.000000, 'Lyon': 23.720930, 'Birmingham': 0.000000, 'Göthenburg': 15.813953 },
    '28': { percentage: 0.06211968, 'Antwerp': 35.510204, 'Wrocław': 19.183673, 'Lyon': 26.530612, 'Birmingham': 0.816327, 'Göthenburg': 17.959184 },
    '29': { percentage: 0.06566937, 'Antwerp': 44.401544, 'Wrocław': 13.899614, 'Lyon': 25.096525, 'Birmingham': 0.772201, 'Göthenburg': 15.830116 },
    '30': { percentage: 0.05958418, 'Antwerp': 42.127660, 'Wrocław': 21.702128, 'Lyon': 20.425532, 'Birmingham': 0.425532, 'Göthenburg': 15.319149 },
    '31': { percentage: 0.06516227, 'Antwerp': 38.521401, 'Wrocław': 17.120623, 'Lyon': 22.178988, 'Birmingham': 0.389105, 'Göthenburg': 21.789883 },
    '32': { percentage: 0.06338742, 'Antwerp': 43.200000, 'Wrocław': 14.800000, 'Lyon': 22.800000, 'Birmingham': 0.400000, 'Göthenburg': 18.800000 },
    '33': { percentage: 0.05299189, 'Antwerp': 50.239234, 'Wrocław': 17.224880, 'Lyon': 12.440191, 'Birmingham': 0.000000, 'Göthenburg': 20.095694 },
    '34': { percentage: 0.05882353, 'Antwerp': 41.810345, 'Wrocław': 18.103448, 'Lyon': 21.120690, 'Birmingham': 0.862069, 'Göthenburg': 18.103448 },
    '35': { percentage: 0.06541582, 'Antwerp': 37.596899, 'Wrocław': 17.054264, 'Lyon': 26.356589, 'Birmingham': 0.000000, 'Göthenburg': 18.992248 },
    '36': { percentage: 0.05831643, 'Antwerp': 44.782609, 'Wrocław': 18.260870, 'Lyon': 19.565217, 'Birmingham': 0.434783, 'Göthenburg': 16.956522 },
    '37': { percentage: 0.06110548, 'Antwerp': 41.493776, 'Wrocław': 14.937759, 'Lyon': 25.726141, 'Birmingham': 0.000000, 'Göthenburg': 17.842324 },
    '38': { percentage: 0.01242394, 'Antwerp': 0.0000000, 'Wrocław': 0.0000000, 'Lyon': 0.0000000, 'Birmingham': 0.000000, 'Göthenburg': 100.000000 },
};

    
let showOverlayModal = false; // Added this modal control variable
    let showBoxModal = false; // Added this modal control variable
    let selectedBox = null;

    function openOverlayModal(box) {
        showOverlayModal = true; // control display of the modal
        selectedBox = box; // sele the selectbox
    }

    function openBoxModal(box) {
        showBoxModal = true; // control dispaly of modal
        selectedBox = box; // set the seletedbox
    }

    // Function to calculate percentage
    function calculatePercentage(percentage) {
        console.log("hello:", percentage); // just check
        const result = ((percentage * 3944) / 20000) * 100; // calculating
        console.log("see:", result); // for checking
        return result; // give result
    }
</script>

<div class="container">
    <div class="headerbox"> 
        <h1>Relative Delivery Time-Frequency and Associated Distribution Plants</h1>
    </div>
    {#each Object.entries(manualPercentages) as [id, data]}
        <div class="box">
            <div class="overlay" 
                style="height: {data.percentage * 100}%" 
                on:click={() => openOverlayModal({id, data})}></div>
            <div>{id} days</div>
            <PieChart {data}/>
            <button on:click={() => openBoxModal({id, data})}>Open Box Modal</button> <!-- add botton to open Box Modal -->
        </div>
    {/each}
</div>

<div class="annotation">the blue area is interactive</div>

{#if showOverlayModal}
    <Modal bind:showModal={showOverlayModal}>
        <h3 slot="header">{(calculatePercentage(selectedBox.data.percentage)).toFixed(2)}% of all orders were completed in {selectedBox.id} days</h3>
        <p>
            This blue section of this box represents the frequency 
            of all completed orders which were executed in {selectedBox.id} days 
            from the order date to the delivery date. This is shown in 
            comparison to the maximum frequency which was observed at 23 days 
            in order to increase readability.
        </p>
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '18'}
    <Modal bind:showModal={showBoxModal}>
        <BoxModal18 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '19'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal19 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '20'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal20 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '21'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal21 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '22'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal22 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '23'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal23 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '24'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal24 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '25'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal25 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '26'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal26 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '27'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal27 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '28'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal28 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '29'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal29 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '30'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal30 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '31'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal31 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '32'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal32 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '33'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal33 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '34'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal34 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '35'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal35 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '36'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal36 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '37'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal37 />
    </Modal>
{/if}

{#if showBoxModal && selectedBox.id === '38'}
    <Modal bind:showModal={showBoxModal}>
        <Boxmodal38 />
    </Modal>
{/if}

<style>
    .headerbox {
        position: fixed; /* Fix the position of the header box */
        top: 0;
        left: 0;
        right: 0;
        display: flex;
        justify-content: center;
        background-color: whitesmoke;
        height: 100px;
        width: 1412px;
        border: 1px solid black;
        margin-left: 47.5px;
        z-index: 999; /* Ensure the header box is on top */
    }
    .container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        margin-top: 200px; /* Adjust the top margin to leave space for the header box */
        margin-bottom: 400px;
        background-color: whitesmoke; /* Set the background color of the container */
        z-index: 1;
    }
    .box {
        position: relative;
        width: 300px;
        height: 500px; /* Increased height to accommodate the pie chart */
        margin: 10px; /* Updated margin for visual consistency */
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
        border: 1px solid black;
        z-index: 1;
    }
    .overlay {
        width: 100%;
        background-color: rgb(126, 192, 200);
        cursor: pointer;
    }
    .annotation {
        position: fixed;
        right: 10px;
        bottom: 10px;
        background: rgba(0, 0, 0, 0.7);
        color: white;
        padding: 8px;
        border-radius: 4px;
        font-size: 14px;
    }


</style>






















