<script>
    import { onMount } from 'svelte';
    import Chart from 'chart.js/auto';
  
    export let data; // 从父组件接收的数据
  
    let canvas; // 用于绑定<canvas>元素
  
    onMount(() => {
      const ctx = canvas.getContext('2d');
      const pieChart = new Chart(ctx, {
          type: 'pie',
          data: {
              labels: ['Antwerp', 'Wrocław', 'Lyon', 'Birmingham', 'Göthenburg DC'],
              datasets: [{
                  data: [data.Antwerp, data.Wrocław, data.Lyon, data.Birmingham, data.Göthenburg],
                  backgroundColor: ['red', 'blue', 'green', 'yellow', 'purple'],
                  borderColor: ['white', 'white', 'white', 'white', 'white'],
                  borderWidth: 1
              }]
          },
          options: {
              responsive: true,
              plugins: {
                  legend: {
                      position: 'top',
                  },
                  tooltip: {
                      enabled: true
                  }
              }
          }
      });
    });
  </script>
  
  <canvas bind:this={canvas}></canvas>
  

  

  
  

  